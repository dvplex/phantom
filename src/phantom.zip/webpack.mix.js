let mix = require('laravel-mix');

mix.js('resources/js/app.js', 'public/js')
	.styles(['resources/css/login.css'], 'public/css/login.css')
	.styles(['resources/sass/*.css'], 'public/css/after.css')
	.sass('resources/sass/app.scss', 'public/css')

require('./vendor/dvplex/Phantom/src/include.mix.js');
require('./Modules/Admin/webpack.mix.js');

if (mix.inProduction()) {
	mix.version();
}
