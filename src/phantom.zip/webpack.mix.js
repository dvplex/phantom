let mix = require('laravel-mix');

mix.js('resources/js/app.js', 'public/js')
	.styles(['resources/css/login.css'], 'public/css/login.css')
	.styles(['resources/sass/*.css'], 'public/css/after.css')
	.sass('resources/sass/app.scss', 'public/css')
	//CMS js and sass/css - if you change the theme you should change the path here.
	.js('app/CMS/Themes/phantom/js/app.js','public/js/fp.js').vue()
	.sass('app/CMS/Themes/phantom/sass/app.scss', 'public/css/fp.css')
	.styles(['app/CMS/Themes/phantom/sass/*.css'], 'public/css/fp_after.css')

require('./vendor/dvplex/phantom/src/include.mix.js');
require('./Modules/Admin/webpack.mix.js');

if (mix.inProduction()) {
	mix.version();
}
