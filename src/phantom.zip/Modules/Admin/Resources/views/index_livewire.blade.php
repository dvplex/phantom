@extends('phantom::layouts.master')

@section('content')
	<div class="row">
		<div class="col-6">
			<livewire:modal-button type="add" target="#addMenu" include="modules::addModule" title="Add Module"/>
		</div>
		<div class="col-6">

			<livewire:search sid="moduleSearch"/>

		</div>
	</div>
	<div class="card card-primary m-t-1 card-outline card-tabs">
		<div class="card-header border-bottom-0">
			<h3 class="card-title">
				{{ __('modules::messages.Modules') }}
			</h3>
		</div>
		<div class="card-body table-responsive">
			<livewire:module-search/>
		</div>
	</div>
	<livewire:modal-dialog mid="addMenu"/>

@stop
