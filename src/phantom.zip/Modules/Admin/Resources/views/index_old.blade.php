@extends('phantom::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: {!! config('admin.name') !!} -  Built with DVPLEX Phantom!
    </p>
    <p>
    </p>

    <div class="card">
        <div class="card-body">
	        {!! $form !!}
        </div>
        <form method="post">
            @csrf
            <input type="text" name="layout_name" value="default">
            <div id="test">
                <span v-pre>{{ $lt }}</span>
            </div>

            <textarea name="test" style="display: none;"></textarea>
            <button id="saveLayout" class="btn btn-primary">Save</button>
        </form>
    </div>

@stop
