<?php

Route::group(['middleware' => ['auth']], function () {
	Route::get('/{lang?}/admin', 'AdminController@index')->name('phantom.modules.admin@index');
	Route::get('/{lang?}/admin/search/', 'AdminController@search')->name('phantom.modules.admin@search');
	Route::get('/{lang?}/admin/add/', 'AdminController@create')->name('phantom.modules.admin@create');
	Route::get('/{lang?}/admin/show/{id}/', 'AdminController@show')->name('phantom.modules.admin@show');
	Route::get('/{lang?}/admin/modify/{id}/', 'AdminController@edit')->name('phantom.modules.admin@edit');
	Route::post('/{lang?}/admin/add/', 'AdminController@store')->name('phantom.modules.admin@store');
	Route::post('/{lang?}/admin/edit/', 'AdminController@update')->name('phantom.modules.admin@update');
	Route::post('/{lang?}/admin/delete/', 'AdminController@destroy')->name('phantom.modules.admin@destroy');

});

