<?php
Route::group(['middleware' => ['web'],'namespace'=>'App\CMS\Http\Controllers'], function () {
	Route::get('/{lang?}', 'HomeController@index')->name('frontpage.index');
});
