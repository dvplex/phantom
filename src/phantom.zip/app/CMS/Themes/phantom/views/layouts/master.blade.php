<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
@include('frontpage::layouts.head')
<body>
<div id="app">
    @include('frontpage::layouts.header')
	<main role="main">
		@yield('content')
	</main>
    @include('frontpage::layouts.footer')
</div>
</body>
<!-- Scripts -->
<script src="{{ asset('js/fp.js') }}" defer></script>
</html>
