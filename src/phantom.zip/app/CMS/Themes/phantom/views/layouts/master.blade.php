<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
@include('cms::layouts.head')
<body>
<div id="app">
    @include('cms::layouts.header')
	<main role="main">
		@yield('content')
	</main>
    @include('cms::layouts.footer')
</div>
</body>
<!-- Scripts -->
<script src="{{ asset('js/fp.js') }}" defer></script>
</html>
