<?php

namespace app\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;

class LoginController extends Controller {
	/*
	|--------------------------------------------------------------------------
	| Login Controller
	|--------------------------------------------------------------------------
	|
	| This controller handles authenticating users for the application and
	| redirecting them to your home screen. The controller uses a trait
	| to conveniently provide its functionality to your applications.
	|
	*/

	use AuthenticatesUsers;

	/**
	 * Where to redirect users after login.
	 *
	 * @var string
	 */
	protected $redirectTo = '/admin';

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware('guest')->except('logout');
	}

	protected function credentials(Request $request) {
		$field = filter_var($request->get($this->username()), FILTER_VALIDATE_EMAIL)
			? $this->username()
			: 'username';


		return [
			$field     => $request->get($this->username()),
			'password' => $request->password,
		];
	}

	function authenticated(Request $request, $user) {
		phantom()->phantom_prefs($user);
		phantom()->set_cookies($user);
		//custom redirect more than one slash
		//return redirect(app()->getLocale().'/admin/devices');

	}

	public function showLoginForm() {
		$creds = phantom()->get_cookies();
		return view('phantom::auth.login',compact('creds'));
	}

	public function logout(Request $request){
		setcookie('phantom','',time()-3600);
		$request->session()->invalidate();
		$this->guard()->logout();
		return redirect('/login');
	}
}
