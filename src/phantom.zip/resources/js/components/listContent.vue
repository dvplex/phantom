<template>
	<div>
		<div class="alert dark bg-danger dvplex-alerts pad-0" role="alert">
			<p>
				<slot></slot>
			</p>
		</div>
	</div>
</template>

<script>
	export default {
		props: ['hasContent'],

		data() {
			return {
			}
		},
		methods: {
		},
		computed: {},
		mounted() {
		},

		created() {
		}
	}
</script>
