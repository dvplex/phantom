<template>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card card-default">
					<div class="card-header">
						{{ title }}
					</div>
					<div class="card-body">
						{{ body }}
						<ul>
							<li v-for="name in names" v-text="name"></li>
						</ul>
						<input type="text" v-model="newName">
						<button @click="addName">Add name</button>
						<h1>{{ HelloMessage }}</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		props: ['title','body'],

		data() {
			return {
				message: 'Hello World',
				newName: '',
				names: ['test', 'test1', 'Joe', 'Jane']
			}
		},
		methods: {
			addName() {
				this.names.push(this.newName)
				this.newName = '';
			}
		},
		computed: {
			HelloMessage() {
				return this.message.split('').reverse().join('');
			}
		},
		mounted() {
		}
	}
</script>
