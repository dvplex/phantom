<template>
	<form method="get" :action="action" @submit.prevent="$parent.search[id].doSearch($event,1)">
		<slot></slot>
		<div class="input-search input-search-dark">
			<i class="input-search-icon fas fa-search ml-3" aria-hidden="true"></i>
			<input :id="id" type="text" class="form-control" name="q" :placeholder="$parent.trans.Search" v-model="$parent.search[id].param">
			<button v-if="$parent.search[id].param" class="input-search-close icon fas fa-times" name="reset" type="button" @click="$parent.search[id].resetSearch($event,id)" aria-label="Close"></button>

		</div>
	</form>
</template>

<script>
	import {phantomSearch} from '../PhantomSearch';
	export default {
		props: ['searchId', 'action', 'id', 'currentPage', 'orderByDir', 'orderById', 'orderByFields','perPage'],

		data() {
			return {
				oByF:''
			}
		},
		methods: {
			doSearch() {
				let evt = {
					target: {}
				}
				evt.target.action = this.action;
				evt.search_id = this.id;
				this.$parent.search[this.id].doSearch(evt);
				this.$parent.isForm = false;
			}
		},
		computed: {},
		mounted() {
			this.doSearch();
		},
		created() {
			let data = {};
			data.app = this.$parent;
			if (this.orderByFields) {
				data.orderByFields = JSON.parse(this.orderByFields);
				if (this.orderByDir=='asc') {
					data.orderByFields[this.orderById]='wb-triangle-up';
				}
				else if (this.orderByDir=='desc') {
					data.orderByFields[this.orderById]='wb-triangle-down';
				}
			}
			data.page = '1';
			data.id= this.id;
			if (this.orderById)
				data.orderById = this.orderById;
			if (this.orderByDir)
				data.orderByDir = this.orderByDir;
			if (this.currentPage)
				data.page = this.currentPage;
			if (this.perPage)
				data.perPage = this.perPage;
			data.param = '';
			data.subAction = this.action;
			if (this.searchId) {
				data.param = this.searchId;
			}
			this.$parent.search[this.id] = new phantomSearch(data);
		}
	}
</script>
