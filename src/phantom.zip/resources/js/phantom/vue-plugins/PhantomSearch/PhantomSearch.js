import pSearch from './components/search.vue';

class phantomSearch {

	constructor(data) {
		this.old_field = '';
		this.orderByFields = {}
		this.originalData = {
			orderAsc: false,
			orderByDir: '',
			orderById: '',
			app: '',
			page: '',
			param: '',
			subAction: '',
			currentPage: '',
			perPage: '',
		}
		for (let field in this.originalData) {
			this[field] = this.originalData[field];
		}
		this.sort = {};
		for (let field in data) {
			this[field] = data[field];
		}
	}

	orderBy(field) {
		this.currentPage = '';
		if (!this.orderByFields) {
			this.orderByFields = {};
			this.orderByFields[field] = 'sort-up'
			this.orderByDir = 'asc';
		}

		if (this.old_field && this.old_field != field) {
			this.orderByFields[this.old_field] = 'sort';
			this.orderByDir = '';

		}
		this.orderById = field;
		if (this.orderByDir == 'asc') {
			this.orderByFields[field] = 'fa-sort-down';
			this.orderByDir = 'desc';
		}
		else if (this.orderByDir == 'desc') {
			this.orderByFields[field] = 'fa-sort';
			this.orderByDir = '';
		}
		else {
			this.orderByFields[field] = 'fa-sort-up';
			this.orderByDir = 'asc';
		}
		this.old_field = field;

		let evt = {
			target: {}
		}
		evt.target.action = this.subAction;
		this.doSearch(evt,0,this.id)
	}

	gotoPage(url,per_page) {
		let evt = {
			target: {}
		}
		let pp ='';
		if(per_page) {
			pp = '&per_page='+per_page;
			this.app.search[this.id].perPage=per_page;
		}

		let oby = '&orderByName=' + this.orderById + '&orderByDir=' + this.orderByDir+pp;
		evt.target.action = url + oby;
		this.currentPage = url + oby;
		this.doSearch(evt,0,this.id);
		return;

	}

	resetSearch(e,id) {
		this.param = '';
		let evt = {
			target: {
				action: this.subAction
			}
		}
		return this.doSearch(evt,0,id);
	}

	doSearch(e, initial,search_id) {
		if (typeof search_id != "undefined")
			e.search_id = search_id
		if (typeof (e.target[1]) != "undefined")
			e.search_id= $(e.target[1]).attr('id')
		let oby = '';
		let per_page ='';
		let app = this.app;
		this.app.$Progress.start();
		if (app) {
			app.isForm = false;
		}
		if (initial)
			this.page = 1;
		if (this.orderById)
			oby = '&orderByName=' + this.orderById + '&orderByDir=' + this.orderByDir;
		let mark ='';
		if (e.target.action.match(/\?/))
			mark = '&';
		else
			mark = '?';
		if (this.perPage)
			per_page = '&per_page='+this.perPage;

		let eta = e.target.action + mark+'q=' + this.param + '&page=' + this.page + oby+per_page+'&rand'+new Date().getTime();
		if (this.currentPage && !initial){
			eta = e.target.action+'&rand'+new Date().getTime();
		}
		axios.get(eta)
			.then(response => {
				app.onSuccess(response.data,e.search_id);
				this.app.$Progress.finish()

			})
			.catch(errors => {
				//console.log(errors.data)
			})
	}
}

const search = {
	install(Vue, options) {
		Vue.component('phantom-search', pSearch).default
		Vue.mixin({
			mounted() {
			},
		});
	}
};

export {
	search, phantomSearch
}
