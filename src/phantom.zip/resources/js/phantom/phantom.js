import Form from './form';
import {search} from './vue-plugins/PhantomSearch/PhantomSearch.js';
import * as lang from "vuejs-datepicker/src/locale";

Vue.component('side-modal', require('./components/modalSide.vue').default);
Vue.component('phantom-menu', require('./components/phantomMenu.vue').default);
Vue.component('list-content', require('./components/listContent.vue').default);
//Vue.config.productionTip = false
//Vue.config.devtools = false
Vue.use(search);

const app = new Vue({
	el: '#app',
	data: {
		service: [],
		counter: 0,
		languages: lang,
		isForm: true,
		search: {},
		trans: {},
		hasContent: {},
		search_id: 0,
		Vue: this,
		valData: 0,
		form: new Form({
			formData: {},
		}),
	},
	computed: {},
	methods: {
		deleteRow(index) {
			this.service.splice(index, 1)
			if (this.form.formData.hasOwnProperty('services_' + index))
				delete this.form.formData['services_' + index];
			if (this.form.formData.hasOwnProperty('count_' + index))
				delete this.form.formData['count_' + index];
		},
		addRow: function () {
			this.service.push({
				id: '',
			})
		},
		notEmptyObject(someObject) {
			if (typeof someObject == 'undefined')
				return 0;
			return Object.keys(someObject).length
		},
		formPath(path) {
			if (this.valData)
				return path + '/edit/';
			else
				return path + '/add/';
		},

		formReset() {
			this.form.reset();
			this.valData = false;
		},

		deleteItem(item, path) {
			this.$swal({
				title: this.trans['Confirm delete'],
				text: this.trans['Delete slogan'],
				type: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: this.trans.Delete,
				cancelButtonText: this.trans.Cancel
			}).then((result) => {
				if (result.value) {
					this.form.formData = item;
					this.form.originalData.formData = item;
					let e = {};
					e.target = {};
					e.target.action = path;
					this.valData = 2;
					this.onSubmit(e);
				}
			})
		},

		deleteItems(item, path) {
			return this.deleteItem(item, path)
		},

		editItems(item) {
			return this.editItem(item)
		},

		editItem(item) {
			let reserved;
			for (let field in item) {
				if (item[field] != null && typeof (item[field]) == 'object') {
					let arr = [];
					if (/reserved/.test(field)) {
						reserved = field.split('_');
						reserved = reserved[1];
						for (let [key, value] of Object.entries(item[field])) {
							arr.push(key);
							arr[key] = value;
						}
						item[field] = arr;
						this[reserved] = item[field];
					}

				}
			}
			this.valData = 1;
			this.form.formData = item;
			this.form.originalData.formData = item;

			if (item.user_avatar) {
				this.doCrop(item, true);
			}
		},
		doCrop(item, edit) {
			let userAvatar = '';
			$('.cropit-preview-image-container').remove();
			$('#crop-input').val('');
			$('.slider-wrapper').hide();
			$('.image-editor').cropit('destroy');
			if (edit)
				userAvatar = '/images/avatar/' + item.user_avatar;
			$('.image-editor').cropit({
				allowDragNDrop: false,
				imageState: {
					src: userAvatar
				},
				onFileChange: function () {
					$('.slider-wrapper').show();
				}
			});
		},
		passHidden(e, keyval) {
			for (var k in keyval) {
				this.form.formData[k] = keyval[k];
			}
			return this.onSubmit(e);
		},

		onSubmit(e) {
			this.isForm = true;
			let obj = this.form.originalData.formData;
			if (obj && Object.keys(obj).length === 0 && obj.constructor === Object) {
				this.form.originalData.formData = this.form.formData;
			}
			this.form.submit('POST', e.target.action)
				.then(fld => {
					if (this.isForm) {
						let oby = '';
						if (this.search[fld].orderById)
							oby = '&orderByName=' + this.search[fld].orderById + '&orderByDir=' + this.search[fld].orderByDir;
						let act = this.search[fld].subAction + '?q=' + this.search[fld].param + '&page=' + this.search[fld].page + oby;
						if (this.valData == 2)
							act = this.search[fld].subAction + '?q=' + this.search[fld].param + '&page=1';
						axios.get(act)
							.then(response2 => {
								this.onSuccess(response2.data,fld);
								return false;
							})
							.catch(errors => {
							})
					} else {
						this.onSuccess(response,fld);
					}
				})

				.catch(error => {
					console.log(error);
				})
		},
		onSuccess(response, search_id) {
			if (response) {
				this.hasContent[search_id] = true;
				for (var i = 0; i < app.$children.length; i++) {
					if (app.$children[i].$options.name == 'response-content-' + search_id) {
						app.$children[i].$destroy();
					}
				}
				let fillContent = Vue.extend({
					name: 'response-content-' + search_id,
					template: '<div>' + response + '</div>',
				});
				let child = new fillContent({
					data: {
						searchId: search_id
					},
					computed: {},
					methods: {
						orderClass(id) {
							if (app.search[search_id].orderByFields instanceof Object && app.search[search_id].orderByFields[id])
								return app.search[search_id].orderByFields[id];
							else {
								return 'wb-sort-vertical';
							}
						},
						orderBy(field) {
							return app.search[search_id].orderBy(field);
						},
						doSearch() {
							return this.search[search_id].doSearch();
						},
						editItems(item) {
							return app.editItem(item)
						},
						deleteItems(item, path) {
							return app.deleteItem(item, path)
						}
					},
					created() {
					},
					//el: app.$el.querySelector('.phantom-content.' + response.id),
					parent: app,
				});
				$('.phantom-content.' + search_id).html('<div class="response-content-' + search_id + '">')
				child.$mount(app.$el.querySelector('.response-content-' + search_id));
			} else {
				this.$el.querySelector('.phantom-content.' + search_id).innerHTML = '';
				this.hasContent[search_id] = false;
			}
			if ($('.modal').length) {
				$('.modal').modal('hide');
			}
			if (this.valData == 1)
				var action = 'Updated';
			else if (this.valData == 2)
				var action = 'Deleted';
			else
				var action = 'Created';
			if (this.isForm) {
				this.$swal({
					title: this.trans[action],
					text: this.trans[action + ' slogan'],
					timer: 1500,
					type: 'success',
					showConfirmButton: false,
				})
			}
			this.valData = 0;
			this.form = new Form({
					formData: {},
				}
			)
		},
		onFileChange(e) {
			var files = e.target.files || e.dataTransfer.files;
			if (!files.length)
				return;
			this.createImage(files[0]);
		},
		createImage(file) {
			var reader = new FileReader();
			var vm = this;

			reader.onload = (e) => {
				app.form.formData.userAvatarData = e.target.result;
			};
			reader.readAsDataURL(file);
		},
	},
	mounted() {
		for (let fld in this.search) {
			if (!this.search[fld].subAction && this.$el.querySelector('.phantom-content.' + fld) != null && !this.$el.querySelector('.phantom-content .' + fld).hasChildNodes()) {
				this.hasContent[fld] = false;
			}
		}
		axios.post('/api/alerts/getTrans')
			.then(response => {
				this.trans = response.data;
			})
	},
	created() {
	},

});

