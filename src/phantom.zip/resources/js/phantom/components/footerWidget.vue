<template>
	<div class="footer-time">
		<button class="btn btn-secondary btn-xs btn-none">{{ date }}</button>
		<button class="btn btn-secondary btn-xs btn-none">{{ time }}</button>
	</div>
</template>

<script>
	export default {
		props: ['hasContent'],

		data() {
			return {
				date:'',
				time:''
			}
		},
		methods: {
			getDate() {
				return moment().format('dddd, MMMM Do YYYY');
			},
			getTime() {
				return moment().format('H:mm ZZ');
			}
		},
		computed: {},
		mounted() {
		},

		created() {
			let that =this
			phantomEvent.$on('locale_changed',function () {
				that.date = that.getDate()
				that.time  = that.getTime()
			})
			let interval = setInterval(() =>{
				this.date = this.getDate()
				this.time  = this.getTime()
			} , 30000);
		}
	}
</script>
