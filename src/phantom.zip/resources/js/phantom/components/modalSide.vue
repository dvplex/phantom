<template>
	<div class="modal fade" :id="id" :aria-labelledby="id" role="dialog" aria-hidden="true" style="display: none;">
		<div class="modal-dialog modal-sidebar modal-xl">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">
						<slot name="modal-title"></slot>
						<slot name="edit-item"></slot>
					</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close" @click="formReset">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">
					<p>
						<slot name="modal-body">
						</slot>
					</p>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		props: ['id', 'formReset', 'formPath', 'addRow', 'deleteRow'],

		data() {
			return {}
		},
		methods: {},
		computed: {},
		mounted() {
		}
	}
</script>
