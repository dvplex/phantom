<template>
	<div class="modal fade" :id="id" :aria-labelledby="id" role="dialog" aria-hidden="true" style="display: none;">
		<div class="modal-dialog modal-simple modal-sidebar modal-sm">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="closeButton" data-dismiss="modal" aria-label="Close" @click="formReset">
						<span aria-hidden="true">×</span>
					</button>
					<h3 class="modal-title">
						<slot name="modal-title"></slot><slot name="edit-item"></slot>
					</h3>
				</div>
				<div class="modal-body">
					<p>
						<slot name="modal-body">
						</slot>
					</p>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		props: ['id','formReset','formPath'],

		data() {
			return {
			}
		},
		methods: {},
		computed: {},
		mounted() {
		}
	}
</script>
