<template>
	<div>
		<slot name="content"></slot>
		<button class="btn btn-default nb">
			<slot name="save"></slot>
		</button>
	</div>
</template>

<script>
	export default {
		props: ['id', 'formReset', 'formPath'],

		data() {
			return {}
		},
		methods: {},
		computed: {},
		mounted() {
			$(function () {

				$('.nb').click(function (e) {
					e.stopImmediatePropagation();
					let d = $('.dd').nestable('serialize');
					axios.post('/api/menu/buildTree', {
						menuTree: d,
					})
						.then(response => {
							window.location.reload();
						})
				})

			})
		}
	}
</script>
