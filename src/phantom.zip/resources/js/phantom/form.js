class Errors {
	constructor() {
		this.errors = {}
	}

	get(field) {
		if (this.errors[field]) {
			return this.errors[field][0];
		}
	}

	record(errors) {
		this.errors = errors;
	}
	clear(field) {
		if (field) {
			delete this.errors[field];

			return;
		}

		this.errors = {};
	}

	has(field) {
		return this.errors.hasOwnProperty(field)
	}

	any() {
		return Object.keys(this.errors).length > 0;
	}

}

class Form {
	constructor(data) {
		this.originalData = data;

		for (let field in data) {
			this[field] = data[field];
		}
		this.errors = new Errors();
	}

	reset() {
		this.formData = {}
		this.originalData = {}
		this.originalData.formData = {}
		this.errors.clear();

	}

	data() {
		let data = {};
		for (let property in this.originalData.formData)
			data[property] = this.originalData.formData[property];
		return data;
	}

	submit(requestType, url) {
		return new Promise((resolve, reject) => {

			let $rt = requestType.toLowerCase();
			axios[$rt](url, this.data())
				.then(response => {
					this.onSuccess(response.data);

					resolve(response.data);
				})
				.catch(error => {
					this.onFail(error.response.data.errors);

					reject(error.response.data.errors);
				});

		})
	}

	onSuccess(data) {
		this.reset()
		return data;
	}

	onFail(errors) {
		return this.errors.record(errors)

	}
}

export default Form;

