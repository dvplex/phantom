(function (global, factory) {
	if (typeof define === "function" && define.amd) {
		define('/dashboard/v1', ['jquery', './../Section/Site'], factory);
	} else if (typeof exports !== "undefined") {
		factory(require('jquery'), require('./../Section/Site'));
	} else {
		var mod = {
			exports: {}
		};
		factory(global.jQuery, global.Site);
		global.dashboardV1 = mod.exports;
	}
})(this, function (_jquery, _Site) {
	'use strict';

	var _jquery2 = babelHelpers.interopRequireDefault(_jquery);

	(0, _jquery2.default)(document).ready(function ($$$1) {
		(0, _Site.run)();

		// Widget Timeline
		// ---------------


		// Widget Linepoint
		// ----------------

	});
});