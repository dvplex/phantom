/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');
//menu minimize and side sub menus click event; full screen app
//side menu plugin


import * as moment from "moment/moment.js"
window.moment = moment;
window.Vue = require('vue').default;
import VueSweetalert2 from 'vue-sweetalert2';

Vue.use(VueSweetalert2);

import VueProgressBar from 'vue-progressbar'

Vue.use(VueProgressBar, {
	location: 'top',
	position:'fixed',
	color: 'red',
	failedColor: 'red',
	thickness: '3px'
})

import Datepicker from 'vuejs-datepicker'

Vue.component('date-picker', Datepicker);


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */
window.phantomEvent = new Vue();
import vSelect from 'vue-select'

Vue.component('v-select', vSelect);

require('./phantom/phantom');
require('./adminlte');
import ace from 'ace-builds';
window.ace = ace
import Swal from 'sweetalert2'
window.Swal = Swal
require("ace-builds/webpack-resolver");
require("ace-builds/src-noconflict/mode-json");
require("ace-builds/src-noconflict/ext-language_tools");
$(function () {
	$('[data-toggle="tooltip"]').tooltip();
	var hash = window.location.hash;
	if (hash) {
		$(".tab-pane-search[data-target!='" + hash + "']").removeClass('search-active');
		$(".tab-pane-search[data-target='" + hash + "']").addClass('search-active');
	}
	hash && $('ul.nav a[href="' + hash + '"]').tab('show');

	$('.nav-tabs a').click(function (e) {
		$(this).tab('show');
		var scrollmem = $('body').scrollTop() || $('html').scrollTop();
		window.location.hash = this.hash;
		$('html,body').scrollTop(scrollmem);
		$(".tab-pane-search[data-target!='" + this.hash + "']").removeClass('search-active');
		$(".tab-pane-search[data-target='" + this.hash + "']").addClass('search-active');
	});
	$('.sidebar a').each(function () {
		if ($(this).attr('href')==window.location||$(this).attr('href')==window.location.pathname) {
			$(this).addClass('active');
			$(this).removeAttr('href');
			$(this).parents('li').addClass('menu-open');
			$(this).parents('li').children(':first-child').addClass('active');
		}
	})
})