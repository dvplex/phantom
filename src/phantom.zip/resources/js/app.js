/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');
require('./global/Plugin/asscrollable');
//menu minimize and side sub menus click event; full screen app
require('./assets/examples/v1');
//side menu plugin
require('./assets/Plugin/menu');
require('./global/Plugin/material');


window.Vue = require('vue');
import VueSweetalert2 from 'vue-sweetalert2';

Vue.use(VueSweetalert2);

import VueProgressBar from 'vue-progressbar'

Vue.use(VueProgressBar, {
	position:'absolute',
	color: 'red',
	failedColor: 'red',
	height: '3px'
})

import Datepicker from 'vuejs-datepicker'

Vue.component('date-picker', Datepicker);


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */
window.phantomEvent = new Vue();
import vSelect from 'vue-select'

Vue.component('v-select', vSelect);

require('./phantom/phantom');
$(function () {
	$('[data-toggle="tooltip"]').tooltip();
	var hash = window.location.hash;
	if (hash) {
		$(".tab-pane-search[data-target!='" + hash + "']").removeClass('search-active');
		$(".tab-pane-search[data-target='" + hash + "']").addClass('search-active');
	}
	hash && $('ul.nav a[href="' + hash + '"]').tab('show');

	$('.nav-tabs a').click(function (e) {
		$(this).tab('show');
		var scrollmem = $('body').scrollTop() || $('html').scrollTop();
		window.location.hash = this.hash;
		$('html,body').scrollTop(scrollmem);
		$(".tab-pane-search[data-target!='" + this.hash + "']").removeClass('search-active');
		$(".tab-pane-search[data-target='" + this.hash + "']").addClass('search-active');
	});

	var current = location;
	$('.site-menu li a').each(function () {
		var $this = $(this);
		if ($this.attr('href') == current) {
			$this.parent().addClass('active is-shown');
			$this.parent().parent().parent().addClass('active open');
		}
	})
})