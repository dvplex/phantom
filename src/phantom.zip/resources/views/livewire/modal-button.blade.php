<div>
	@if($type=="add")
		<button class="btn btn-add btn-animate btn-animate-side btn-outline-primary" data-target="{{ $target }}" data-backdrop="static" data-keyboard="false"  type="button">
			<span><i class="icon wb-plus" aria-hidden="true"></i>{{ __('modules::messages.add module') }}</span>
		</button>
	@endif
</div>
