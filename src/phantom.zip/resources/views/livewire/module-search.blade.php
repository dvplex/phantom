<div>
	<table class="table table-hover table-responsive-sm">
		<thead>
		<th class="phantom-th order-by" wire:click="orderBy('module_name')">
			<i class="fas fa-sort{{ $orderDir }}"></i>{{ __('modules::messages.Name')}}</th>
		<th class="phantom-th">{{ __('modules::messages.Description')}}</th>
		<th class="phantom-th">{{ __('messages.Action')}}</th>
		</thead>
		<tbody>
		@foreach($modules as $module)
			<tr>
				<td>{{ $module->module_name }}</td>
				<td>{{ $module->module_description }}</td>
				<td>
					<livewire:modal-button type="edit" target="#addMenu" include="modules::addModule" title="edit Module"/>
					<button class="btn btn-xs" title="delete"><i class="far fa-trash-alt"></i></button>
				</td>
			</tr>
		@endforeach
		</tbody>
	</table>
	{{ $modules->links() }}
</div>
