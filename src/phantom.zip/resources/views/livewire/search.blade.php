<div>
	<div class="input-search input-search-dark">
		<i aria-hidden="true" class="input-search-icon fas fa-search ml-3"></i>
		<input type="text" wire:model.lazy="search" class="form-control" placeholder="Search...">
		@if($search)
			<button class="input-search-close icon fas fa-times" name="reset" type="button" wire:click="doSearch" aria-label="Close"></button>
		@endif
	</div>
</div>
