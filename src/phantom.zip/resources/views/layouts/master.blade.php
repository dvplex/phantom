<!DOCTYPE html>
<html class="no-js css-menubar" lang="{{ app()->getLocale() }}">
@include('layouts.head')
<body class="hold-transition sidebar-mini layout-navbar-fixed text-sm">
<div class="wrapper">
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
	your browser</a> to improve your experience.</p>
<![endif]-->
@include('layouts.top-navbar')
@include('layouts.side-navbar')
<!-- Page -->

<div id="app" class="content-wrapper">
	<div class="content-header">
		@include('layouts.page-header')
	</div>
	<div class="content">
		<vue-progress-bar></vue-progress-bar>
		@yield('content')
	</div>
</div>
<!-- End Page -->

@include('layouts.footer')
<!-- Core  -->
@includeIf('layouts.user_defined')
</div>
<script src="{{ asset('js/app.js') }}"></script>
@include(config('phantom.modules.current') .'::layouts.scripts')
</body>
</html>
