<?php
return [

	'Confirm delete'   => 'Are you sure?',
	'delete slogan'    => 'You won\'t be able to revert this!',
	'Delete'           => 'Yes, delete it!',
	'Cancel'           => 'Cancel',
	'Deleted'          => 'Deleted!',
	'Deleted slogan'   => 'The record was deleted!',
	'Created'          => 'Created!',
	'Created slogan'   => 'The record was created!',
	'Updated'          => 'Updated!',
	'Updated slogan'   => 'The record was updated!',
	'Search'           => 'Search...',
	'No results found' => 'No results found! Please refine your search.',

];
