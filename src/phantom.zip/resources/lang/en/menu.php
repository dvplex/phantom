<?php
return  [
	'hello' => 'hello',
	'menu' => 'menu',
	'Profile' => 'Profile',
	'Settings' => 'Settings',
	'Dashboard' => 'Dashboard',
	'Fiber' => 'Fiber routes',
];