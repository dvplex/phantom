<?php
return  [
	'Action' => 'Action',
	'details' => 'details',
	'Save' => 'Save',
	'of' => 'of',
	'showing' => 'showing',
	'records' => 'records',
	'Login' => 'Login',
	'Logout' => 'Logout',
	'show' => 'show',
	'all' => 'all',
];