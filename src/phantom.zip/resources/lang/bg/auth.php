<?php

return [

	/*
	|--------------------------------------------------------------------------
	| Authentication Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are used during authentication for various
	| messages that we need to display to the user. You are free to modify
	| these language lines according to your application's requirements.
	|
	*/

	'failed'            => 'These credentials do not match our records.',
	'throttle'          => 'Too many login attempts. Please try again in :seconds seconds.',
	'username/email'    => 'Потребителско име / E-mail',
	'password'          => 'Парола',
	'remember me'       => 'Запомни ме',
	'login'             => 'Вход',
	'Enter credentials' => 'Въведете паролата си, за да възобновите сесията',
	'Sign different' => 'Или влезте като друг потребител',

];
