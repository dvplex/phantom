<?php

return [

	'Confirm delete' => 'Сигурни ли сте?',
	'Delete slogan'  => 'Промените са окончателни!',
	'Delete'         => 'Да, изтрий!',
	'Cancel'         => 'Отказ',
	'Deleted'        => 'Изтрит!',
	'Deleted slogan' => 'Записът беше изтрит успешно!',
	'Created'        => 'Създаден!',
	'Created slogan' => 'Записът беше създаден успешно!',
	'Updated'        => 'Обновен!',
	'Updated slogan' => 'Записът беше обновен успешно!',
	'Search'         => 'Търсене...',

];
