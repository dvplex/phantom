<?php
return  [
	'hello' => 'здравейте',
	'menu' => 'меню',
	'Profile' => 'Профил',
	'Settings' => 'Настройки',
	'Dashboard' => 'Начало',
];