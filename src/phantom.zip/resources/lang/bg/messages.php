<?php
return  [
	'Action' => 'Действие',
	'details' => 'детайли',
	'Save' => 'Запис',
	'of' =>'от',
	'showing' => 'показване',
	'records' => 'записа',
	'Login' => 'Вход',
	'Logout' => 'Изход',
	'show' => 'покажи',
	'all' => 'всички',
];
