<?php

return [
	'user_primary_key' => 'id',
	'cms_theme'        => env('CMS_THEME', 'phantom'),
	'locales'          => ['bg', 'en'],
];
